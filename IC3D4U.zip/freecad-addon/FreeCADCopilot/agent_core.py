"""
FreeCAD AI Copilot — agent_core.py

Thin wrapper around LM Studio's OpenAI-compatible chat API.
Called from copilot_panel._Worker (background QThread) so it
never blocks FreeCAD's main thread.
"""

import re

from openai import OpenAI

from system_prompt import SYSTEM_PROMPT

# ── Config ─────────────────────────────────────────────────────────────────────
BASE_URL    = "http://localhost:1234/v1"
MODEL       = "qwen3-coder-30b-a3b-instruct"
MAX_TOKENS  = 4096
TEMPERATURE = 0.1
MAX_TURNS   = 6   # keep last N user/assistant exchanges in the context window

_client = OpenAI(base_url=BASE_URL, api_key="lm-studio")


# ── Public API ─────────────────────────────────────────────────────────────────

def get_completion(history: list) -> str:
    """
    Send the conversation history to LM Studio and return the raw
    reply string.

    Parameters
    ----------
    history : list of {"role": str, "content": str}
        The full conversation so far (system message is prepended here).
    """
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    # Trim old turns to stay within context; keep most-recent N pairs
    messages += history[-(MAX_TURNS * 2):]

    resp = _client.chat.completions.create(
        model=MODEL,
        messages=messages,
        max_tokens=MAX_TOKENS,
        temperature=TEMPERATURE,
    )
    return resp.choices[0].message.content


def extract_code(text: str) -> str:
    """
    Pull the first ```python … ``` block from the model's reply.
    Returns an empty string if no fenced block is found and the reply
    does not look like a bare Python script.
    """
    match = re.search(r"```python\s*(.*?)```", text, re.DOTALL)
    if match:
        return match.group(1).strip()

    # Fallback: treat the whole reply as code if it opens with a
    # recognisable Python token (model skipped the fence).
    stripped = text.strip()
    if stripped.startswith(("import ", "FreeCAD", "doc =", "#")):
        return stripped

    return ""
