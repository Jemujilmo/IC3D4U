import FreeCAD
import Part

doc = FreeCAD.newDocument("VacuumBagPiercingTool")

# Create the base disc
disc = doc.addObject("Part::Cylinder", "BaseDisc")
disc.Radius = 30/2   # 30mm diameter
disc.Height = 3      # 3mm thick

# Create the handle shaft
cylinder = doc.addObject("Part::Cylinder", "HandleShaft")
cylinder.Radius = 10/2  # 10mm diameter
cylinder.Height = 45    # 45mm tall

# Create the conical spike
cone = doc.addObject("Part::Cone", "ConicalSpike")
cone.Radius1 = 5/2   # 5mm diameter at base
cone.Radius2 = 0.3/2 # 0.3mm diameter at tip
cone.Height = 20     # 20mm tall

# Position the base disc at bottom
disc.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 0),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Position the handle shaft centered on top of the disc
cylinder.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 3),  # Place on top of disc (3mm height)
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Position the conical spike centered on top of the handle
cone.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 48),  # Place on top of cylinder (3+45=48mm)
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Fuse all parts together
fuse1 = doc.addObject("Part::Fuse", "Fuse1")
fuse1.Base = disc
fuse1.Tool = cylinder

fuse2 = doc.addObject("Part::Fuse", "Fuse2")
fuse2.Base = fuse1
fuse2.Tool = cone

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass