import FreeCAD
import Part

doc = FreeCAD.newDocument("HalfInchBarbedTFitting")

# ── Dimensions for 1/2" I.D. barbed T-fitting ─────────────────────────────────
# Hose inner diameter: 1/2" = 12.7 mm
# Barb tip must exceed hose I.D. to grip; shank sits inside the hose
bore_r  = 5.0     # inner flow bore radius  → 10.0 mm bore dia
shank_r = 9.0     # arm shank radius        → 18.0 mm shank dia
barb_r  = 10.5    # barb tip radius         → 21.0 mm tip dia (grips 12.7 mm hose)
body_r  = 14.0    # junction sphere radius  → 28.0 mm dia (scaled up with shank)
arm_len = 42.0    # arm length from sphere centre to tip (mm)
n_barbs = 3       # barbs per arm

def make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs):
    """
    Builds one barbed arm along the +Z axis:
      z = 0       -> base (connects to junction body)
      z = arm_len -> tip (hose entry end)

    Profile:
      - Straight shank cylinder for the full length
      - Tapered nozzle at tip (insertion chamfer)
      - 3 barb ridges: gentle forward ramp, steep retention face
      - Through-bore already cut
    """
    # ── Shank ─────────────────────────────────────────────────────────────────
    solid = Part.makeCylinder(shank_r, arm_len,
                              FreeCAD.Vector(0, 0, 0),
                              FreeCAD.Vector(0, 0, 1))

    # ── Nozzle taper at tip (makes hose easier to push on) ───────────────────
    tip_len = 4.0
    tip = Part.makeCone(shank_r, bore_r + 0.5, tip_len,
                        FreeCAD.Vector(0, 0, arm_len - tip_len),
                        FreeCAD.Vector(0, 0, 1))
    solid = solid.fuse(tip)

    # ── Barb ridges ───────────────────────────────────────────────────────────
    # First barb centre 9 mm from tip; subsequent barbs spaced 8 mm toward base
    barb_rise = 3.0   # forward (insertion) ramp  — gradual
    barb_drop = 1.2   # back (retention) face     — steep, resists pullout
    for i in range(n_barbs):
        z0 = arm_len - 9.0 - i * 8.0
        ramp = Part.makeCone(shank_r, barb_r, barb_rise,
                             FreeCAD.Vector(0, 0, z0),
                             FreeCAD.Vector(0, 0, 1))
        face = Part.makeCone(barb_r, shank_r, barb_drop,
                             FreeCAD.Vector(0, 0, z0 + barb_rise),
                             FreeCAD.Vector(0, 0, 1))
        solid = solid.fuse(ramp).fuse(face)

    # ── Inner bore (1.5 mm past base so it merges cleanly with junction bore) ─
    bore = Part.makeCylinder(bore_r, arm_len + 1.5,
                             FreeCAD.Vector(0, 0, -1.5),
                             FreeCAD.Vector(0, 0, 1))
    solid = solid.cut(bore)
    return solid


# ── Build three arms ──────────────────────────────────────────────────────────

# Right arm → +X direction
arm_right = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_right.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), 90)

# Left arm → -X direction
arm_left = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_left.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), -90)

# Stem arm → -Z direction (the downward branch of the T)
arm_stem = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_stem.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 180)

# ── Central junction sphere ───────────────────────────────────────────────────
junction = Part.makeSphere(body_r)

# Through-bore along X axis (left <-> right flow path)
jbore_x = Part.makeCylinder(bore_r, (body_r + 1) * 2,
                             FreeCAD.Vector(-(body_r + 1), 0, 0),
                             FreeCAD.Vector(1, 0, 0))

# Half-bore along -Z axis (junction -> stem flow path)
jbore_z = Part.makeCylinder(bore_r, body_r + 1,
                             FreeCAD.Vector(0, 0, -(body_r + 1)),
                             FreeCAD.Vector(0, 0, 1))

junction = junction.cut(jbore_x).cut(jbore_z)

# ── Fuse all four bodies into one printable solid ─────────────────────────────
fitting = junction.fuse(arm_right).fuse(arm_left).fuse(arm_stem)

# ── Add to document ───────────────────────────────────────────────────────────
part = doc.addObject("Part::Feature", "HalfInchBarbedTFitting")
part.Shape = fitting

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass