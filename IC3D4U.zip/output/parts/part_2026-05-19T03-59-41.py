import FreeCAD
import Part

doc = FreeCAD.newDocument("VacuumFitting")

# Base disc for the T-fitting
disc = doc.addObject("Part::Cylinder", "Disc")
disc.Radius = 12.5  # 25mm diameter for 1/2" I.D. tubing
disc.Height = 3
disc.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 0),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Main shaft (vertical arm of T-fitting)
main_shaft = doc.addObject("Part::Cylinder", "MainShaft")
main_shaft.Radius = 3.25  # 6.5mm diameter for 1/2" I.D. tubing
main_shaft.Height = 20
main_shaft.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 3),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Horizontal arm (perpendicular to main shaft)
horizontal_arm = doc.addObject("Part::Cylinder", "HorizontalArm")
horizontal_arm.Radius = 3.25  # 6.5mm diameter for 1/2" I.D. tubing
horizontal_arm.Height = 15
horizontal_arm.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, -15/2, 3),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 90)
)

# Fillet for smooth transition at junction
fillet = doc.addObject("Part::Fillet", "Fillet")
fillet.Base = disc
fillet.Edges = [(1, 2.0, 2.0)]

doc.recompute()

# Fuse all sections into one solid body
fused_fitting = doc.addObject("Part::Fuse", "FusedFitting")
fused_fitting.Base = disc
fused_fitting.Tool = main_shaft

doc.recompute()

# Fuse the horizontal arm to the fused fitting
final_fuse = doc.addObject("Part::Fuse", "FinalFusion")
final_fuse.Base = fused_fitting
final_fuse.Tool = horizontal_arm

doc.recompute()

# Remove intermediate objects from view (optional)
disc.ViewObject.Visibility = False
main_shaft.ViewObject.Visibility = False
horizontal_arm.ViewObject.Visibility = False

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass