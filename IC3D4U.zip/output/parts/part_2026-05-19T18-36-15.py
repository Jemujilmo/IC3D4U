import FreeCAD
import Part

doc = FreeCAD.newDocument("VacuumBagPiercingTool_v2")

# ── Dimensions ─────────────────────────────────────────────────────────────────
# Hose fitting I.D. reference: 1/2" = 12.7mm — brace must exceed this
disc_r   = 15.0   # base flange radius     → 30mm dia
disc_h   = 3.0    # base flange thickness
brace_r  = 7.5    # brace cone wide end    → 15mm dia  (> 12.7mm fitting I.D.)
shaft_r  = 3.0    # shaft radius           → 6.0mm dia (slides into fitting)
brace_h  = 7.0    # height of brace taper section
shaft_h  = 26.0   # shaft cylinder height
point_h  = 6.0    # pointed tip taper height
tip_r    = 0.5    # near-zero tip radius   (avoids degenerate geometry)

# Z positions — built bottom (disc) → top (point)
z0 = 0.0
z1 = z0 + disc_h        #  3.0  — top of disc / base of brace
z2 = z1 + brace_h       # 10.0  — top of brace / base of shaft
z3 = z2 + shaft_h       # 36.0  — top of shaft / base of point
z4 = z3 + point_h       # 42.0  — tip

# ── PART 1: Spike + disc (one fused solid) ────────────────────────────────────

# Base flange disc — sits on top of the vacuum bag, too wide to enter fitting
disc = Part.makeCylinder(disc_r, disc_h,
                         FreeCAD.Vector(0, 0, z0),
                         FreeCAD.Vector(0, 0, 1))

# Brace cone — wide at the bottom (brace_r), narrows to shaft_r at top.
# When the spike is pushed into the fitting from above, this cone seats against
# the fitting entrance and stops the spike going in too deep.
brace = Part.makeCone(brace_r, shaft_r, brace_h,
                      FreeCAD.Vector(0, 0, z1),
                      FreeCAD.Vector(0, 0, 1))

# Shaft — uniform cylinder the washer slides along
shaft = Part.makeCylinder(shaft_r, shaft_h,
                          FreeCAD.Vector(0, 0, z2),
                          FreeCAD.Vector(0, 0, 1))

# Pointed tip — tapers from shaft_r to near-zero for clean bag puncture
point = Part.makeCone(shaft_r, tip_r, point_h,
                      FreeCAD.Vector(0, 0, z3),
                      FreeCAD.Vector(0, 0, 1))

spike_solid = disc.fuse(brace).fuse(shaft).fuse(point)

part1 = doc.addObject("Part::Feature", "VacuumPiercingSpike")
part1.Shape = spike_solid

# ── PART 2: Sliding washer (separate moveable piece) ─────────────────────────
# Inner hole: 7mm dia (3.5mm radius) — slides freely over 6mm shaft; too small
#             to pass the 15mm brace, so it stops dead on the bag surface.
# Outer dia:  70mm — extends 20mm beyond the 30mm disc on all sides, giving
#             comfortable thumb area to press the bag flat onto tacky tape.
# Thickness:  5mm — rigid enough to transmit even thumb pressure around the seal.

washer_or = 35.0   # outer radius → 70mm dia  (20mm thumb pad beyond 30mm disc)
washer_ir = 3.5    # inner radius → 7mm dia   (shaft clearance: +1mm on diameter)
washer_h  = 5.0

washer_outer = Part.makeCylinder(washer_or, washer_h,
                                  FreeCAD.Vector(0, 0, 0),
                                  FreeCAD.Vector(0, 0, 1))
washer_bore  = Part.makeCylinder(washer_ir, washer_h + 2,
                                  FreeCAD.Vector(0, 0, -1),
                                  FreeCAD.Vector(0, 0, 1))
washer_solid = washer_outer.cut(washer_bore)

# Place the washer beside the spike in the viewport so both are visible
washer_solid.translate(FreeCAD.Vector(50, 0, 0))

part2 = doc.addObject("Part::Feature", "SlidingWasher")
part2.Shape = washer_solid

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass

# ── Dimensions for 1/2" I.D. barbed T-fitting ─────────────────────────────────
# Hose inner diameter: 1/2" = 12.7 mm
# Barb tip must exceed hose I.D. to grip; shank sits inside the hose
bore_r  = 7.0     # inner flow bore radius  → 14.0 mm bore dia (~1/2" hose I.D.), 2 mm wall
shank_r = 9.0     # arm shank radius        → 18.0 mm shank dia
barb_r  = 10.5    # barb tip radius         → 21.0 mm tip dia (grips 12.7 mm hose)
body_r  = 14.0    # junction sphere radius  → 28.0 mm dia (scaled up with shank)
arm_len = 42.0    # arm length from sphere centre to tip (mm)
n_barbs = 3       # barbs per arm

def make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs):
    """
    Builds one barbed arm along the +Z axis:
      z = 0       -> base (connects to junction body)
      z = arm_len -> tip (hose entry end)

    Profile:
      - Straight shank cylinder for the full length
      - Tapered nozzle at tip (insertion chamfer)
      - 3 barb ridges: gentle forward ramp, steep retention face
      - Through-bore already cut
    """
    # ── Shank ─────────────────────────────────────────────────────────────────
    solid = Part.makeCylinder(shank_r, arm_len,
                              FreeCAD.Vector(0, 0, 0),
                              FreeCAD.Vector(0, 0, 1))

    # ── Nozzle taper at tip (makes hose easier to push on) ───────────────────
    tip_len = 4.0
    tip = Part.makeCone(shank_r, bore_r + 0.8, tip_len,
                        FreeCAD.Vector(0, 0, arm_len - tip_len),
                        FreeCAD.Vector(0, 0, 1))
    solid = solid.fuse(tip)

    # ── Barb ridges ───────────────────────────────────────────────────────────
    # First barb centre 9 mm from tip; subsequent barbs spaced 8 mm toward base
    barb_rise = 3.0   # forward (insertion) ramp  — gradual
    barb_drop = 1.2   # back (retention) face     — steep, resists pullout
    for i in range(n_barbs):
        z0 = arm_len - 9.0 - i * 8.0
        ramp = Part.makeCone(shank_r, barb_r, barb_rise,
                             FreeCAD.Vector(0, 0, z0),
                             FreeCAD.Vector(0, 0, 1))
        face = Part.makeCone(barb_r, shank_r, barb_drop,
                             FreeCAD.Vector(0, 0, z0 + barb_rise),
                             FreeCAD.Vector(0, 0, 1))
        solid = solid.fuse(ramp).fuse(face)

    # ── Inner bore (1.5 mm past base so it merges cleanly with junction bore) ─
    bore = Part.makeCylinder(bore_r, arm_len + 1.5,
                             FreeCAD.Vector(0, 0, -1.5),
                             FreeCAD.Vector(0, 0, 1))
    solid = solid.cut(bore)
    return solid


# ── Build three arms ──────────────────────────────────────────────────────────

# Right arm → +X direction
arm_right = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_right.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), 90)

# Left arm → -X direction
arm_left = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_left.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(0, 1, 0), -90)

# Stem arm → -Z direction (the downward branch of the T)
arm_stem = make_barbed_arm(arm_len, bore_r, shank_r, barb_r, n_barbs)
arm_stem.rotate(FreeCAD.Vector(0, 0, 0), FreeCAD.Vector(1, 0, 0), 180)

# ── Central junction — flat cylinder (prints without overhangs) ───────────────
# Spans z = -body_r to z = +body_r so all three arm bases connect at the origin.
# Flat top and bottom eliminate the unsupported equator the sphere caused.
junction = Part.makeCylinder(body_r, body_r * 2,
                             FreeCAD.Vector(0, 0, -body_r),
                             FreeCAD.Vector(0, 0, 1))

# Through-bore along X axis (left <-> right flow path)
jbore_x = Part.makeCylinder(bore_r, (body_r + 1) * 2,
                             FreeCAD.Vector(-(body_r + 1), 0, 0),
                             FreeCAD.Vector(1, 0, 0))

# Half-bore along -Z axis (junction -> stem flow path)
jbore_z = Part.makeCylinder(bore_r, body_r + 1,
                             FreeCAD.Vector(0, 0, -(body_r + 1)),
                             FreeCAD.Vector(0, 0, 1))

junction = junction.cut(jbore_x).cut(jbore_z)

# ── Fuse all four bodies into one printable solid ─────────────────────────────
fitting = junction.fuse(arm_right).fuse(arm_left).fuse(arm_stem)

# ── Add to document ───────────────────────────────────────────────────────────
part = doc.addObject("Part::Feature", "HalfInchBarbedTFitting")
part.Shape = fitting

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass