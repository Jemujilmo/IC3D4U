import FreeCAD
import Part

doc = FreeCAD.newDocument("VacuumBagPiercingTool_v2")

# ── Dimensions ─────────────────────────────────────────────────────────────────
# Hose fitting I.D. reference: 1/2" = 12.7mm — brace must exceed this
disc_r   = 15.0   # base flange radius     → 30mm dia
disc_h   = 3.0    # base flange thickness
brace_r  = 7.5    # brace cone wide end    → 15mm dia  (> 12.7mm fitting I.D.)
shaft_r  = 5.0    # cone base radius at brace-top → 10mm dia
brace_h  = 7.0    # height of brace taper section
taper_h  = 32.0   # height of continuous spike taper (brace-top to tip)
tip_r    = 0.5    # near-zero tip radius   (avoids degenerate geometry)

# Z positions — built bottom (disc) → top (tip)
z0 = 0.0
z1 = z0 + disc_h        #  3.0 — top of disc / base of brace
z2 = z1 + brace_h       # 10.0 — top of brace / base of continuous taper
z3 = z2 + taper_h       # 42.0 — tip

# ── PART 1: Spike + disc (one fused solid) ────────────────────────────────────

# Base flange disc — sits on top of the vacuum bag, too wide to enter fitting
disc = Part.makeCylinder(disc_r, disc_h,
                         FreeCAD.Vector(0, 0, z0),
                         FreeCAD.Vector(0, 0, 1))

# Brace cone — wide at bottom (brace_r), narrows to shaft_r at top.
# Seats against the fitting entrance to stop the spike going in too deep.
brace = Part.makeCone(brace_r, shaft_r, brace_h,
                      FreeCAD.Vector(0, 0, z1),
                      FreeCAD.Vector(0, 0, 1))

# Continuous spike taper — single cone from shaft_r (5mm) all the way to the tip.
# Replaces the old cylinder+tip-cone pair: no flat shaft section, steady taper only.
taper = Part.makeCone(shaft_r, tip_r, taper_h,
                      FreeCAD.Vector(0, 0, z2),
                      FreeCAD.Vector(0, 0, 1))

spike_solid = disc.fuse(brace).fuse(taper)

part1 = doc.addObject("Part::Feature", "VacuumPiercingSpike")
part1.Shape = spike_solid

# ── PART 2: Sliding washer (separate moveable piece) ─────────────────────────
# Inner hole must be larger than brace_r (7.5mm) so the washer can slide from
# the tip, past the brace, and rest flat against the underside of the disc.
# Outer dia: 70mm — 20mm thumb pad extending beyond the 30mm disc on all sides.
# Thickness: 5mm — rigid enough to press bag flat onto tacky tape evenly.

washer_or = 35.0   # outer radius → 70mm dia
washer_ir = 8.0    # inner radius → 16mm dia  (just over 15mm brace, slides past)
washer_h  = 5.0

washer_outer = Part.makeCylinder(washer_or, washer_h,
                                  FreeCAD.Vector(0, 0, 0),
                                  FreeCAD.Vector(0, 0, 1))
washer_bore  = Part.makeCylinder(washer_ir, washer_h + 2,
                                  FreeCAD.Vector(0, 0, -1),
                                  FreeCAD.Vector(0, 0, 1))
washer_solid = washer_outer.cut(washer_bore)

# Offset the washer beside the spike so both are visible in viewport
washer_solid.translate(FreeCAD.Vector(90, 0, 0))

part2 = doc.addObject("Part::Feature", "SlidingWasher")
part2.Shape = washer_solid

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass