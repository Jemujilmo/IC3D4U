import FreeCAD
import Part

doc = FreeCAD.newDocument("Spike")

# Create the conical taper
cone = doc.addObject("Part::Cone", "Cone")
cone.Radius1 = 3.5/2  # 3.5mm tip diameter
cone.Radius2 = 0      # Sharp point
cone.Height = 20      # 20mm long

# Create the handle shaft
cylinder = doc.addObject("Part::Cylinder", "Cylinder")
cylinder.Radius = 10/2  # 10mm diameter
cylinder.Height = 45    # 45mm long

# Position the cone
cone.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 0),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Position the cylinder to connect with the cone
cylinder.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 20),  # Place it right after the cone
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass