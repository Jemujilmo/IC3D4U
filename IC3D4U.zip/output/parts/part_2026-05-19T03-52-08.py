import FreeCAD
import Part

doc = FreeCAD.newDocument("VacuumBagPiercingTool")

# Base disc
disc = doc.addObject("Part::Cylinder", "Disc")
disc.Radius = 15  # 30mm diameter
disc.Height = 3
disc.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 0),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Neck (conical frustum)
neck = doc.addObject("Part::Cone", "Neck")
neck.Radius1 = 7  # 14mm diameter at base
neck.Radius2 = 3.25  # 6.5mm diameter at top
neck.Height = 7
neck.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 3),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Shaft (cylinder)
shaft = doc.addObject("Part::Cylinder", "Shaft")
shaft.Radius = 3.25  # 6.5mm diameter
shaft.Height = 30
shaft.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 10),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Dome end cap (hemisphere)
dome = doc.addObject("Part::Sphere", "Dome")
dome.Radius = 3.25
dome.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 40),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

# Fuse all sections into one solid body
fused_tool = doc.addObject("Part::Fuse", "FusedTool")
fused_tool.Base = disc
fused_tool.Tool = neck

doc.recompute()

# Fuse the shaft to the fused tool
shaft_fuse = doc.addObject("Part::Fuse", "ShaftFuse")
shaft_fuse.Base = fused_tool
shaft_fuse.Tool = shaft

doc.recompute()

# Fuse the dome to the shaft fuse
final_fuse = doc.addObject("Part::Fuse", "FinalFusion")
final_fuse.Base = shaft_fuse
final_fuse.Tool = dome

doc.recompute()

# Remove intermediate objects from view (optional)
disc.ViewObject.Visibility = False
neck.ViewObject.Visibility = False
shaft.ViewObject.Visibility = False
dome.ViewObject.Visibility = False

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass