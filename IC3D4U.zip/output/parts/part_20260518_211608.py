import FreeCAD
import Part

doc = FreeCAD.newDocument("Spike")

# Create the conical taper
cone = doc.addObject("Part::Cone", "Cone")
cone.Radius1 = 3.5/2  # 3.5mm tip diameter
cone.Radius2 = 0      # Sharp point
cone.Height = 20      # 20mm long

# Position the cone
cone.Placement = FreeCAD.Placement(
    FreeCAD.Vector(0, 0, 0),
    FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), 0)
)

doc.recompute()
try:
    import FreeCADGui
    FreeCADGui.activeDocument().activeView().fitAll()
except Exception:
    pass