import * as vscode from 'vscode';

interface Message {
    role: 'system' | 'user' | 'assistant';
    content: string;
}

function extractCode(text: string): string {
    const match = text.match(/```(?:python)?\s*\n([\s\S]*?)```/);
    return match ? match[1].trim() : text.trim();
}

function getConfig() {
    const cfg = vscode.workspace.getConfiguration('ic3d4u');
    return {
        baseUrl: cfg.get<string>('lmStudioUrl', 'http://localhost:1234/v1'),
        model:   cfg.get<string>('modelName',   'qwen3-coder-30b-a3b-instruct'),
        maxTokens: cfg.get<number>('maxTokens', 3000),
    };
}

export async function callLMStudio(
    prompt: string,
    history: Message[],
    systemPrompt: string,
    token: vscode.CancellationToken
): Promise<{ code: string; raw: string }> {
    const { baseUrl, model, maxTokens } = getConfig();

    const messages: Message[] = [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: prompt },
    ];

    const controller = new AbortController();
    token.onCancellationRequested(() => controller.abort());

    let response: Response;
    try {
        response = await fetch(`${baseUrl}/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model,
                messages,
                temperature: 0.1,
                max_tokens: maxTokens,
                stream: false,
            }),
            signal: controller.signal,
        });
    } catch (err: any) {
        if (err.name === 'AbortError') {
            throw new Error('Cancelled');
        }
        throw new Error(
            `Cannot reach LM Studio at ${baseUrl}. Make sure the server is started.`
        );
    }

    if (!response.ok) {
        throw new Error(`LM Studio responded with HTTP ${response.status}`);
    }

    const data = (await response.json()) as {
        choices: { message: { content: string } }[];
    };

    const raw = data.choices[0].message.content;
    const code = extractCode(raw);
    return { code, raw };
}

export function buildHistory(
    history: readonly (vscode.ChatRequestTurn | vscode.ChatResponseTurn)[]
): Message[] {
    const messages: Message[] = [];

    for (const turn of history) {
        if (turn instanceof vscode.ChatRequestTurn) {
            messages.push({ role: 'user', content: turn.prompt });
        } else if (turn instanceof vscode.ChatResponseTurn) {
            const text = turn.response
                .filter((p): p is vscode.ChatResponseMarkdownPart =>
                    p instanceof vscode.ChatResponseMarkdownPart
                )
                .map(p => p.value.value)
                .join('');
            if (text.trim()) {
                messages.push({ role: 'assistant', content: text });
            }
        }
    }

    // Keep last 3 turns (6 messages) to stay within context budget
    return messages.slice(-6);
}
